# 公考指南（开源版）

一个面向公务员考试备考的 Android 学习工具，提供全国时政、常识、成语、申论和速算训练。此仓库仅包含通用开源版本，不含地方专项内容。

## 界面预览

| 学习首页 | 全国时政 |
| --- | --- |
| ![学习首页](docs/images/learn-home.png) | ![全国时政](docs/images/national-affairs.png) |

## 已实现

- 今日 / 学习 / 复习 / 我的四导航
- 全国时政、常识、成语、申论、速算入口
- 搜索空状态与主题筛选面板
- 知识卡、来源与适用期、收藏
- 单选题提交、文字化对错反馈、错因与区别笔记
- 成语回忆揭示、易混对照和辨析题
- 申论素材分区及个人摘记
- 基期量公式、精算/估算切换、数字键盘、±2% 边界判分
- 浏览器本地保存学习状态

## 本地运行

```bash
npm install
npm run dev
```

生产构建：

```bash
npm run build
```

## Android 打包

需要 JDK 21 和 Android Studio / Android SDK：

```bash
npm run android:apk
```

构建产物位于 `android/app/build/outputs/apk/debug/app-debug.apk`。开源版 Android 包名为 `cn.gongkao.guide.opensource`，可与原版同时安装。

## 项目范围

这是学习端的前端首版。学习记录保存在本机；内容导入、云同步和自动内容生成可在后续版本继续扩展。

## 开源协议

本项目采用 [MIT License](LICENSE)。
