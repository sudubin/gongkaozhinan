import { createApp } from "vue";
import App from "./App.vue";
import "./styles.css";
import "./safe-area.css";

createApp(App).mount("#app");
